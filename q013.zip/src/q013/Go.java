package q013;

public class Go {
	public static void main(String[] args) {
		
		Computer myCom = new Computer();
		
		System.out.println(myCom.sum2(1, 2, 3));
		System.out.println(myCom.sum2(1, 2, 3, 4, 5));
		System.out.println(myCom.sum2(1, 2, 3, 4, 5, 6, 7));
		
		
		
	}
}
